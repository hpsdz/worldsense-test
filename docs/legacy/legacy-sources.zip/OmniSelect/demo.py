"""Single-video OmniSelect demo using the shared omnizip Python environment."""
import argparse
import gc
import json
from pathlib import Path
import sys
import time

for stream in (sys.stdout, sys.stderr):
    if hasattr(stream, 'reconfigure'):
        stream.reconfigure(encoding='utf-8')

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent / 'vendor/qwen-omni-utils/src'))
sys.path.insert(0, str(ROOT / 'AudioCLIP'))

import numpy as np
import torch
import torch.nn.functional as F
from torchvision import transforms
from nltk import word_tokenize, pos_tag
import nltk
nltk.data.path.insert(0, str(ROOT/'assets/nltk_data'))
from qwen_omni_utils import process_mm_info
from transformers import Qwen2_5OmniProcessor
from OmniSelect.modeling_qwen2_5_omni import Qwen2_5OmniForConditionalGeneration


def matching(args, frames, audio):
    from model import AudioCLIP
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    model = AudioCLIP(pretrained=str(args.audioclip)).to(device).eval()
    tokens = word_tokenize(args.prompt)
    keywords = [w for w, tag in pos_tag(tokens) if tag.startswith(('NN', 'JJ'))]
    # AudioCLIP expects a list of word lists, not individual strings (characters).
    text_features = F.normalize(model.encode_text([[w] for w in (keywords or tokens)]), dim=-1)
    transform = transforms.Compose([
        transforms.ToPILImage(), transforms.Resize(224, interpolation=transforms.InterpolationMode.BICUBIC),
        transforms.CenterCrop(224), transforms.ToTensor(),
        transforms.Normalize((.48145466, .4578275, .40821073), (.26862954, .26130258, .27577711)),
    ])
    n = len(frames)
    track = torch.as_tensor(np.asarray(audio), dtype=torch.float32).flatten()
    chunk = track.numel() // n
    if chunk < 2048:
        raise ValueError('Audio chunks are too short for AudioCLIP; use fewer frames.')
    chunks = track[:chunk*n].reshape(n, 1, chunk)
    audio_scores, video_scores = [], []
    # Small batches and release AudioCLIP before loading Qwen to fit 8 GB GPUs.
    for i in range(n):
        af = F.normalize(model.encode_audio(chunks[i:i+1].to(device)), dim=-1)
        vf = F.normalize(model.encode_image(transform(frames[i].byte()).unsqueeze(0).to(device)), dim=-1)
        audio_scores.append((model.logit_scale_at.exp().clamp(1,100) * af @ text_features.T).mean().cpu())
        video_scores.append((model.logit_scale.exp().clamp(1,100) * vf @ text_features.T).mean().cpu())
    a, v = torch.stack(audio_scores), torch.stack(video_scores)
    mode = 'uniform' if not keywords or abs(int(v.mean()) - int(a.mean())) <= args.theta else bool(v.mean() > a.mean())
    del model, text_features
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    return a, v, mode


def groups(indices):
    out, current = [], []
    for i in indices:
        if current and i != current[-1] + 1:
            out.append(current)
            current = []
        current.append(i)
    if current:
        out.append(current)
    return out


@torch.inference_mode()
def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--video', type=Path, default=ROOT.parent/'OmniZip-main/assets/example.mp4')
    parser.add_argument('--model', type=Path, default=Path('D:/Models/Qwen2.5-Omni-3B'))
    parser.add_argument('--audioclip', type=Path, default=ROOT/'AudioCLIP/assets/AudioCLIP-Full-Training.pt')
    parser.add_argument('--prompt', default='Describe this video.')
    parser.add_argument('--max-frames', type=int, default=16)
    parser.add_argument('--max-pixels', type=int, default=100352)
    parser.add_argument('--max-new-tokens', type=int, default=64)
    parser.add_argument('--fps', type=float, default=2.0)
    parser.add_argument('--prune-ratio-a', type=float, default=.4)
    parser.add_argument('--prune-ratio-v', type=float, default=.6)
    parser.add_argument('--theta', type=float, default=3.7)
    parser.add_argument('--output', type=Path, default=ROOT/'results/demo.json')
    args = parser.parse_args()
    for path in (args.video, args.model, args.audioclip):
        if not path.exists():
            parser.error(f'Not found: {path}')
    if not 0 <= args.prune_ratio_a < 1 or not 0 <= args.prune_ratio_v < 1:
        parser.error('Pruning ratios must be in [0, 1).')
    if args.max_frames < 2 or args.max_new_tokens < 1 or args.fps <= 0:
        parser.error('Use max-frames >= 2, max-new-tokens >= 1 and fps > 0.')
    torch.manual_seed(0)
    torch.set_num_threads(4)
    start = time.perf_counter()
    processor = Qwen2_5OmniProcessor.from_pretrained(str(args.model), local_files_only=True)
    messages = [
        {'role':'system', 'content':[{'type':'text', 'text':'You are Qwen, a virtual human developed by the Qwen Team, Alibaba Group, capable of perceiving auditory and visual inputs, as well as generating text and speech.'}]},
        {'role':'user', 'content':[{'type':'video', 'video':str(args.video.resolve()), 'max_frames':args.max_frames, 'max_pixels':args.max_pixels, 'fps':args.fps}, {'type':'text', 'text':args.prompt}]},
    ]
    audios, images, videos, kwargs = process_mm_info(messages, use_audio_in_video=True, return_video_kwargs=True)
    if not audios or not len(audios[0]):
        raise ValueError('This demo requires a video with audio.')
    inputs = processor(text=processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True),
                       audio=audios, images=images, videos=videos, fps=kwargs['fps'][0],
                       return_tensors='pt', padding=True, use_audio_in_video=True)
    print('Computing AudioCLIP relevance...', flush=True)
    a, v, mode = matching(args, videos[0], audios[0])
    print(f'AudioCLIP: audio={a.mean().item():.3f}, video={v.mean().item():.3f}, video_first={mode}', flush=True)
    ids = inputs.input_ids[0]
    v_lst = (ids == processor.tokenizer.convert_tokens_to_ids(processor.video_token)).nonzero().flatten().tolist()
    a_lst = (ids == processor.tokenizer.convert_tokens_to_ids(processor.audio_token)).nonzero().flatten().tolist()
    if not v_lst or not a_lst:
        raise ValueError('Expected both video and audio tokens.')
    vg, ag = groups(v_lst), groups(a_lst)
    mapping = {idx: g+1 for seq in (vg,ag) for g,group in enumerate(seq) for idx in group}
    args.prune = True
    # Map sampled-frame scores to actual processor time groups; fixed four-frame
    # pooling in the original assumes 2 FPS even when a frame cap reduces FPS.
    grid_tokens = int(inputs.video_grid_thw[0,1]*inputs.video_grid_thw[0,2])//4
    temporal = int(inputs.video_grid_thw[0,0])
    if len(v) != temporal * 2:
        raise ValueError('Expected two sampled frames per Qwen temporal patch.')
    token_scores = v.reshape(temporal, 2).mean(1).repeat_interleave(grid_tokens)
    cursor, vs = 0, []
    for group in vg:
        # Interleaved audio can split a temporal patch into runs of 1 and 143
        # video tokens; map scores per token before pooling these runs.
        vs.append(token_scores[cursor:cursor+len(group)].mean())
        cursor += len(group)
    assert cursor == token_scores.numel()
    # AudioCLIP audio scores represent equal-duration chunks of the full track.
    # Weight overlap with each actual contiguous audio-token time group.
    edges = torch.linspace(0, len(a_lst), len(a)+1)
    cursor, aus = 0, []
    for group in ag:
        overlap = (torch.minimum(edges[1:], torch.tensor(cursor+len(group))) - torch.maximum(edges[:-1], torch.tensor(cursor))).clamp_min(0)
        aus.append((a*overlap).sum()/overlap.sum())
        cursor += len(group)
    prune_need = {'args':args, 'logits_a':a, 'logits_v':v, 'video_first':mode,
                  'pooled_a':torch.stack(aus), 'pooled_v':torch.stack(vs),
                  'token_id2group':mapping, 'v_lst':v_lst, 'a_lst':a_lst}
    print('Loading Qwen with SDPA (no 4-bit quantization)...', flush=True)
    model = Qwen2_5OmniForConditionalGeneration.from_pretrained(str(args.model), torch_dtype='auto',
                device_map='auto', max_memory={0:'5GiB','cpu':'24GiB'} if torch.cuda.is_available() else None,
                enable_audio_output=False, attn_implementation='sdpa', local_files_only=True).eval()
    inputs = inputs.to(model.device).to(model.dtype)
    for key in ('logits_a','logits_v','pooled_a','pooled_v'):
        prune_need[key] = prune_need[key].to(model.device)
    if torch.cuda.is_available():
        torch.cuda.synchronize()
    generation_start = time.perf_counter()
    output = model.generate(**inputs, use_audio_in_video=True, return_audio=False,
                thinker_do_sample=False, thinker_max_new_tokens=args.max_new_tokens, prune_need=prune_need)
    if torch.cuda.is_available():
        torch.cuda.synchronize()
    elapsed = time.perf_counter()-generation_start
    response = processor.batch_decode(output[:,ids.numel():], skip_special_tokens=True)[0]
    stats = model.thinker.last_compression_stats
    assert stats['total']['after'] < stats['total']['before'], 'Compression did not reduce the sequence.'
    assert stats['query']['before'] == stats['query']['after'], 'Text tokens were removed.'
    result = {'video':str(args.video.resolve()), 'model':str(args.model.resolve()), 'prompt':args.prompt,
              'frames':len(videos[0]), 'sampled_fps':kwargs['fps'][0], 'video_first':mode,
              'audio_score':a.mean().item(), 'video_score':v.mean().item(),
              'prune_ratio_a':args.prune_ratio_a, 'prune_ratio_v':args.prune_ratio_v,
              'tokens':stats, 'response':response, 'generation_seconds':elapsed,
              'total_seconds_including_model_load':time.perf_counter()-start,
              'generated_tokens':output.shape[1]-ids.numel()}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2), flush=True)


if __name__ == '__main__':
    main()
