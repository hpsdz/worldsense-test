import torch
from pathlib import Path
import sys
# Use the project's portable preprocessing snapshot, including PyAV audio decoding.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "vendor" / "qwen-omni-utils" / "src"))
from transformers import Qwen2_5OmniProcessor
from qwen_omni_utils import process_mm_info
import argparse

parser = argparse.ArgumentParser(description="Qwen2.5-Omni Demo Parameters")
parser.add_argument('--video', type=str, default=str(Path(__file__).resolve().parent / "assets/example.mp4"), help='Path to input video file')
parser.add_argument('--describe', type=str, default="Describe this video.", help='Instruction text for the model')
parser.add_argument('--omnizip', action='store_true', help='Whether to enable omnizip')
parser.add_argument('--rho_audio', type=float, default=0.4, help='Merging ratio for audio')
parser.add_argument('--rho_video', type=float, default=0.7, help='Merging ratio for video')
parser.add_argument('--g', type=int, default=3)
parser.add_argument('--contextual_ratio', type=float, default=0.05, help='Contextual ratio')
parser.add_argument('--model', default="D:/Models/Qwen2.5-Omni-3B")
parser.add_argument('--max-frames', type=int, default=16)
parser.add_argument('--max-pixels', type=int, default=100352)
parser.add_argument('--max-new-tokens', type=int, default=128)
args = parser.parse_args()
if not Path(args.video).is_file():
    parser.error(f"Video not found: {args.video}")

if args.omnizip:
    print("Using OmniZip for Inference")
    omnizip_config = {
        "rho_audio": args.rho_audio,
        "rho_video": args.rho_video,
        "g": args.g,
        "contextual_ratio": args.contextual_ratio,
    }
    from omnizip.modeling_qwen2_5_omni import Qwen2_5OmniForConditionalGeneration
else:
    from transformers import Qwen2_5OmniForConditionalGeneration

model_path = args.model
model = Qwen2_5OmniForConditionalGeneration.from_pretrained(
    model_path,
    torch_dtype="auto",
    device_map="auto",
    max_memory={0: "5GiB", "cpu": "24GiB"} if torch.cuda.is_available() else None,
    enable_audio_output=False,
    local_files_only=True,
    attn_implementation="sdpa",
)

if args.omnizip:
    model.thinker.omnizip_config = omnizip_config
processor = Qwen2_5OmniProcessor.from_pretrained(model_path)

conversation = [
    {
        "role": "system",
        "content": [
            {"type": "text", "text": "You are Qwen, a virtual human developed by the Qwen Team, Alibaba Group, capable of perceiving auditory and visual inputs, as well as generating text and speech."}
        ],
    },
    {
        "role": "user",
        "content": [
            {"type": "video", "video": args.video, "max_frames": args.max_frames, "max_pixels": args.max_pixels},
            {"type": "text", "text": args.describe},
        ],
    },
]

# set use audio in video
USE_AUDIO_IN_VIDEO = True

# Preparation for inference
text = processor.apply_chat_template(conversation, add_generation_prompt=True, tokenize=False)
audios, images, videos, video_kwargs = process_mm_info(conversation, use_audio_in_video=USE_AUDIO_IN_VIDEO, return_video_kwargs=True)
num_input_frames = videos[0].shape[0]
if hasattr(model, 'thinker'):
    model.thinker.nframes = num_input_frames
inputs = processor(fps=video_kwargs["fps"][0], text=text, audio=audios, images=images, videos=videos, return_tensors="pt", padding=True, use_audio_in_video=USE_AUDIO_IN_VIDEO)
inputs = inputs.to(model.device).to(model.dtype)


print('Generating...')

from transformers import TextStreamer
streamer = TextStreamer(processor.tokenizer, skip_prompt=True, skip_special_tokens=True)
text_ids = model.generate(**inputs, use_audio_in_video=USE_AUDIO_IN_VIDEO, return_audio=False, thinker_do_sample=False, thinker_max_new_tokens=args.max_new_tokens, streamer=streamer)
if args.omnizip:
    print("OmniZip compression:", model.thinker.last_compression_stats)




